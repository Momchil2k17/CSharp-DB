﻿namespace P02_FootballBetting.Common
{
    public static class ApplicationCommonConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-H3STVF4\SQLEXPRESS;Database=FootballBetting2025;Trusted_Connection=True;";
    }
}
